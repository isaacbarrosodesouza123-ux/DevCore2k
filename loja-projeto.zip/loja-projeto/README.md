# Loja virtual — Vercel + Node + Supabase + Mercado Pago

## 1. Supabase (banco e fotos)
1. supabase.com > New project.
2. SQL Editor > cole todo o `supabase/schema.sql` > Run. (Cria tabelas, bloqueia acesso público via RLS, cria o bucket `products` e migra a loja atual.)
3. Project Settings > API: copie **Project URL** e **service_role key** (secreta).

## 2. Segredos (rode no terminal, ou use geradores online de senha)
```
openssl rand -base64 48   # SESSION_SECRET
openssl rand -base64 32   # ENCRYPTION_KEY
openssl rand -hex 16      # SETUP_TOKEN
```

## 3. Vercel
1. Envie esta pasta para um repositório no GitHub.
2. vercel.com > Add New > Project > importe o repositório.
3. Em Environment Variables cadastre todas as de `.env.example`
   (`BASE_URL` = `https://seudominio.com.br`; `MP_WEBHOOK_SECRET` fica para o passo 6).
4. Deploy.

## 4. Domínio
Vercel > Project > Settings > Domains > Add `seudominio.com.br` (e `www`).
No registrador (Registro.br, GoDaddy…) > DNS, crie exatamente os registros que a Vercel mostrar
(normalmente: `A @ 76.76.21.21` e `CNAME www cname.vercel-dns.com`). O HTTPS é emitido automaticamente.

## 5. Primeira senha (uma única vez)
Abra `https://seudominio.com.br/admin`, informe o `SETUP_TOKEN` e crie a senha (mín. 10 caracteres).
Depois disso a rota de configuração responde 403 para qualquer pessoa. Recomendado: apague `SETUP_TOKEN` da Vercel.

## 6. Mercado Pago
1. mercadopago.com.br/developers > Suas integrações > Criar aplicação (Checkout Pro).
2. Credenciais de produção: copie o **Access Token**. No painel (/admin > Mercado Pago) cole e clique Conectar.
3. Aplicação > Webhooks > Configurar notificações: URL `https://seudominio.com.br/api/mp-webhook`, evento **Pagamentos**.
   Copie a **assinatura secreta** > Vercel > `MP_WEBHOOK_SECRET` > Redeploy.

## 7. Teste completo
1. Vitrine: adicione ao carrinho, informe nome completo, Gmail e cidade. Outra cidade deve ser recusada.
2. Pague (valor baixo, real). Volte à loja: o status só muda por webhook.
3. /admin > LOGS: pedido **aprovado**, com ID da transação, e estoque reduzido.

## Limites conhecidos
- Estoque é conferido no checkout e baixado na aprovação (não é reservado durante o pagamento).
- Estorno marca o pedido como `estornado`, mas não devolve estoque.
- A Vercel Hobby é para uso não comercial; para loja comercial consulte o plano Pro.
