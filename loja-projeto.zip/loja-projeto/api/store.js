import { sb, json } from './_lib.js';
export default async function handler(req, res) {
  if (req.method !== 'GET') return json(res, 405, {});
  const [{ data: s }, { data: p }] = await Promise.all([
    sb.from('settings').select('name,primary_color,address,hours,whats,logo_url,banner_url,profile_url,mp_token_enc').eq('id', 1).single(),
    sb.from('products').select('id,name,description,price,promo_price,stock,image_urls').eq('active', true).order('created_at', { ascending: false })]);
  const { mp_token_enc, ...pub } = s || {};
  json(res, 200, { settings: pub, mpReady: !!mp_token_enc, products: p || [] });
}
