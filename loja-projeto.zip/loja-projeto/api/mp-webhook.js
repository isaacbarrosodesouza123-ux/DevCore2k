import crypto from 'node:crypto';
import { sb, json, mpToken, safeEq, MP } from './_lib.js';
const MAP = { approved: 'aprovado', rejected: 'recusado', cancelled: 'recusado', refunded: 'estornado', charged_back: 'estornado' };
export default async function handler(req, res) {
  if (!process.env.MP_WEBHOOK_SECRET) return json(res, 500, { error: 'webhook secret ausente' });
  const id = String(req.query['data.id'] || req.body?.data?.id || '');
  const sig = req.headers['x-signature'] || '', rid = req.headers['x-request-id'] || '';
  const ts = /ts=(\d+)/.exec(sig)?.[1], v1 = /v1=([a-f0-9]+)/.exec(sig)?.[1];
  if (!id || !ts || !v1) return json(res, 401, { error: 'assinatura ausente' });
  const h = crypto.createHmac('sha256', process.env.MP_WEBHOOK_SECRET).update(`id:${id.toLowerCase()};request-id:${rid};ts:${ts};`).digest('hex');
  if (!safeEq(h, v1)) return json(res, 401, { error: 'assinatura inválida' });
  if ((req.query.type || req.body?.type) !== 'payment') return json(res, 200, { ignored: true });
  const token = await mpToken(); if (!token) return json(res, 200, { ignored: true });
  const r = await fetch(`${MP}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: 'Bearer ' + token } });
  if (!r.ok) return json(res, 500, { error: 'falha ao consultar pagamento' });
  const pay = await r.json();
  const { data: order } = await sb.from('orders').select('*').eq('id', String(pay.external_reference || '')).maybeSingle();
  if (!order) return json(res, 200, { ignored: true });
  if (pay.currency_id !== 'BRL' || Math.abs(Number(pay.transaction_amount) - Number(order.total)) > 0.01) {
    await sb.from('orders').update({ mp_status: 'valor_divergente' }).eq('id', order.id); return json(res, 200, { mismatch: true }); }
  let st = MAP[pay.status] || 'pendente';
  if (order.status === 'aprovado' && st === 'pendente') st = 'aprovado';
  await sb.from('orders').update({ status: st, mp_payment_id: String(pay.id), mp_status: pay.status, paid_at: st === 'aprovado' ? (order.paid_at || new Date().toISOString()) : order.paid_at }).eq('id', order.id);
  if (st === 'aprovado') await sb.rpc('apply_stock', { p_order: order.id });
  json(res, 200, { ok: true });
}
