import { sb, json } from './_lib.js';
export default async function handler(req, res) {
  const { id, email } = req.query;
  if (!/^[0-9a-f-]{36}$/i.test(id || '') || !email) return json(res, 400, { error: 'Informe o número do pedido e o Gmail.' });
  const { data } = await sb.from('orders').select('id,status,total,created_at,order_items(name,qty,unit_price)').eq('id', id).eq('email', String(email).trim().toLowerCase()).maybeSingle();
  if (!data) return json(res, 404, { error: 'Pedido não encontrado.' });
  json(res, 200, data);
}
