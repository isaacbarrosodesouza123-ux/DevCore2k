import { sb, json, cityOk, nameOk, gmailOk, mpToken, MP } from './_lib.js';
export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, {});
  const b = req.body || {}, name = String(b.name || '').trim().replace(/\s+/g, ' '), email = String(b.email || '').trim().toLowerCase();
  if (!nameOk(name)) return json(res, 400, { error: 'Digite seu nome completo (nome e sobrenome).' });
  if (!gmailOk(email)) return json(res, 400, { error: 'Digite um Gmail válido (@gmail.com).' });
  if (!cityOk(b.city)) return json(res, 400, { error: 'Entregamos somente em Porto Velho - RO. Compra não permitida.' });
  const key = String(b.key || ''); if (!/^[\w-]{16,64}$/.test(key)) return json(res, 400, { error: 'Requisição inválida.' });
  const token = await mpToken(); if (!token) return json(res, 503, { error: 'Compras temporariamente indisponíveis.' });
  const old = await sb.from('orders').select('id').eq('idem_key', key).maybeSingle();
  if (old.data) return json(res, 409, { error: 'Este pedido já foi enviado. Consulte pelo número: ' + old.data.id });
  const want = (Array.isArray(b.items) ? b.items : []).slice(0, 30).map(i => ({ id: String(i.id), qty: parseInt(i.qty) }));
  if (!want.length || want.some(i => !(i.qty >= 1 && i.qty <= 20))) return json(res, 400, { error: 'Carrinho inválido.' });
  const { data: prods } = await sb.from('products').select('id,name,price,promo_price,stock').in('id', want.map(i => i.id)).eq('active', true);
  const items = []; let total = 0;
  for (const w of want) {
    const p = (prods || []).find(x => x.id === w.id);
    if (!p) return json(res, 400, { error: 'Produto indisponível.' });
    if (p.stock < w.qty) return json(res, 400, { error: `Estoque insuficiente: ${p.name}.` });
    const unit = p.promo_price != null && Number(p.promo_price) > 0 && Number(p.promo_price) < Number(p.price) ? Number(p.promo_price) : Number(p.price);
    items.push({ product_id: p.id, name: p.name, qty: w.qty, unit_price: unit }); total += unit * w.qty;
  }
  total = Math.round(total * 100) / 100; if (total <= 0) return json(res, 400, { error: 'Valor inválido.' });
  const { data: order, error } = await sb.from('orders').insert({ idem_key: key, name, email, city: 'Porto Velho - RO', total }).select('id').single();
  if (error) return json(res, 409, { error: 'Pedido já em andamento.' });
  await sb.from('order_items').insert(items.map(i => ({ ...i, order_id: order.id })));
  const base = process.env.BASE_URL, back = `${base}/?pedido=${order.id}`;
  const r = await fetch(MP + '/checkout/preferences', { method: 'POST',
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', 'X-Idempotency-Key': order.id },
    body: JSON.stringify({ items: items.map(i => ({ title: i.name, quantity: i.qty, unit_price: i.unit_price, currency_id: 'BRL' })),
      payer: { name, email }, external_reference: order.id, notification_url: base + '/api/mp-webhook',
      back_urls: { success: back, failure: back, pending: back }, auto_return: 'approved' }) });
  const pref = await r.json();
  if (!r.ok || !pref.init_point) { await sb.from('orders').update({ status: 'recusado', mp_status: 'preference_error' }).eq('id', order.id); return json(res, 502, { error: 'Não foi possível iniciar o pagamento.' }); }
  await sb.from('orders').update({ mp_preference_id: pref.id }).eq('id', order.id);
  json(res, 200, { orderId: order.id, init_point: pref.init_point });
}
