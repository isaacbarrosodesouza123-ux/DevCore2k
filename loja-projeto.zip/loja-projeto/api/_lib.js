import { createClient } from '@supabase/supabase-js';
import { SignJWT, jwtVerify } from 'jose';
import crypto from 'node:crypto';
export const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
export const MP = 'https://api.mercadopago.com';
const SECRET = () => new TextEncoder().encode(process.env.SESSION_SECRET);
export const json = (res, code, obj) => res.status(code).json(obj);
export const ip = req => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || '?';
export const cityOk = c => /^porto velho( ro| rondonia)?$/.test(String(c || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z ]+/g, ' ').replace(/\s+/g, ' ').trim());
export const nameOk = n => { n = String(n || '').trim().replace(/\s+/g, ' '); const w = n.split(' '); return n.length <= 120 && w.length >= 2 && w.every(x => /^[\p{L}'-]{2,}$/u.test(x)); };
export const gmailOk = e => /^[a-z0-9][a-z0-9._+-]{4,}@gmail\.com$/.test(String(e || '').trim().toLowerCase());
export const sessionToken = v => new SignJWT({ v }).setProtectedHeader({ alg: 'HS256' }).setIssuedAt().setExpirationTime('8h').sign(SECRET());
export const cookie = (t, max) => `adm=${t}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${max}`;
export async function getAdmin(req) {
  const m = /(?:^|; )adm=([^;]+)/.exec(req.headers.cookie || ''); if (!m) return null;
  try { const { payload } = await jwtVerify(m[1], SECRET()); const { data } = await sb.from('admin').select('*').eq('id', 1).maybeSingle();
    return data && String(data.pw_version) === String(payload.v) ? data : null; } catch { return null; }
}
export async function requireAdmin(req, res) {
  if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'fetch') { json(res, 403, { error: 'forbidden' }); return null; }
  const a = await getAdmin(req); if (!a) { json(res, 401, { error: 'unauthorized' }); return null; } return a;
}
export async function tooMany(req, kind, max = 5) {
  const since = new Date(Date.now() - 15 * 60e3).toISOString();
  const q = f => { const b = sb.from('login_attempts').select('*', { count: 'exact', head: true }).eq('kind', kind).gte('at', since); return f ? b.eq('ip', ip(req)) : b; };
  const [{ count: a }, { count: g }] = await Promise.all([q(true), q(false)]);
  return a >= max || g >= max * 6;
}
export const fail = (req, kind) => sb.from('login_attempts').insert({ ip: ip(req), kind });
const KEY = () => Buffer.from(process.env.ENCRYPTION_KEY, 'base64');
export function enc(t) { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', KEY(), iv), e = Buffer.concat([c.update(t, 'utf8'), c.final()]); return Buffer.concat([iv, c.getAuthTag(), e]).toString('base64'); }
export function dec(s) { const b = Buffer.from(s, 'base64'), d = crypto.createDecipheriv('aes-256-gcm', KEY(), b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8'); }
export async function mpToken() { const { data } = await sb.from('settings').select('mp_token_enc').eq('id', 1).single(); return data?.mp_token_enc ? dec(data.mp_token_enc) : null; }
export const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
