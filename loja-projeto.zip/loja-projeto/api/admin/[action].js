import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { sb, json, getAdmin, requireAdmin, tooMany, fail, sessionToken, cookie, safeEq, enc, MP, ip } from '../_lib.js';
const num = v => { const n = Number(v); return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : null; };
const url = v => (/^(https:\/\/|\/img\/)/.test(String(v || '')) ? String(v) : '');
export default async function handler(req, res) {
  const a = req.query.action, body = req.body || {};
  if (a === 'me') { const ad = await getAdmin(req); const { count } = await sb.from('admin').select('*', { count: 'exact', head: true }); return json(res, 200, { loggedIn: !!ad, setupOpen: count === 0 }); }
  if (a === 'setup' && req.method === 'POST') {
    const { count } = await sb.from('admin').select('*', { count: 'exact', head: true });
    if (count > 0) return json(res, 403, { error: 'Configuração inicial já concluída.' });
    if (await tooMany(req, 'setup')) return json(res, 429, { error: 'Muitas tentativas. Aguarde 15 minutos.' });
    if (!process.env.SETUP_TOKEN || !safeEq(body.token || '', process.env.SETUP_TOKEN)) { await fail(req, 'setup'); return json(res, 403, { error: 'Código de configuração inválido.' }); }
    if (String(body.password || '').length < 10) return json(res, 400, { error: 'A senha precisa ter no mínimo 10 caracteres.' });
    const { error } = await sb.from('admin').insert({ id: 1, pw_hash: await bcrypt.hash(body.password, 12), pw_version: Date.now() });
    return error ? json(res, 403, { error: 'Configuração inicial já concluída.' }) : json(res, 200, { ok: true });
  }
  if (a === 'login' && req.method === 'POST') {
    if (await tooMany(req, 'login')) return json(res, 429, { error: 'Muitas tentativas. Aguarde 15 minutos.' });
    const ad = await getAdmin({ headers: {} }) || (await sb.from('admin').select('*').eq('id', 1).maybeSingle()).data;
    if (!ad) return json(res, 409, { error: 'Administrador ainda não configurado.' });
    if (!(await bcrypt.compare(String(body.password || ''), ad.pw_hash))) { await fail(req, 'login'); return json(res, 401, { error: 'Senha incorreta.' }); }
    await sb.from('login_attempts').delete().eq('ip', ip(req)).eq('kind', 'login');
    res.setHeader('Set-Cookie', cookie(await sessionToken(ad.pw_version), 8 * 3600)); return json(res, 200, { ok: true });
  }
  if (a === 'logout') { res.setHeader('Set-Cookie', cookie('', 0)); return json(res, 200, { ok: true }); }
  const ad = await requireAdmin(req, res); if (!ad) return;
  if (a === 'password' && req.method === 'POST') {
    if (await tooMany(req, 'login')) return json(res, 429, { error: 'Muitas tentativas.' });
    if (!(await bcrypt.compare(String(body.current || ''), ad.pw_hash))) { await fail(req, 'login'); return json(res, 401, { error: 'Senha atual incorreta.' }); }
    if (String(body.next || '').length < 10) return json(res, 400, { error: 'A nova senha precisa ter no mínimo 10 caracteres.' });
    const v = Date.now(); await sb.from('admin').update({ pw_hash: await bcrypt.hash(body.next, 12), pw_version: v }).eq('id', 1);
    res.setHeader('Set-Cookie', cookie(await sessionToken(v), 8 * 3600)); return json(res, 200, { ok: true });
  }
  if (a === 'products') {
    if (req.method === 'GET') return json(res, 200, (await sb.from('products').select('*').order('created_at', { ascending: false })).data);
    if (req.method === 'DELETE') { await sb.from('products').delete().eq('id', String(req.query.id)); return json(res, 200, { ok: true }); }
    const p = { name: String(body.name || '').trim().slice(0, 120), description: String(body.description || '').slice(0, 2000), price: num(body.price),
      promo_price: body.promo_price === '' || body.promo_price == null ? null : num(body.promo_price), stock: Math.max(0, parseInt(body.stock) || 0),
      image_urls: (Array.isArray(body.image_urls) ? body.image_urls : []).map(url).filter(Boolean).slice(0, 10), active: body.active !== false };
    if (!p.name || p.price == null) return json(res, 400, { error: 'Nome e preço válidos são obrigatórios.' });
    const q = body.id ? sb.from('products').update(p).eq('id', body.id) : sb.from('products').insert(p);
    const { error } = await q; return error ? json(res, 400, { error: 'Erro ao salvar.' }) : json(res, 200, { ok: true });
  }
  if (a === 'upload' && req.method === 'POST') {
    const ext = ({ 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' })[body.contentType];
    if (!ext) return json(res, 400, { error: 'Use JPG, PNG ou WEBP.' });
    const path = `${crypto.randomUUID()}.${ext}`, { data, error } = await sb.storage.from('products').createSignedUploadUrl(path);
    if (error) return json(res, 500, { error: 'Falha no upload.' });
    return json(res, 200, { signedUrl: data.signedUrl, publicUrl: sb.storage.from('products').getPublicUrl(path).data.publicUrl });
  }
  if (a === 'settings') {
    if (req.method === 'GET') { const { mp_token_enc, ...s } = (await sb.from('settings').select('*').eq('id', 1).single()).data; return json(res, 200, { ...s, mpConnected: !!mp_token_enc }); }
    const s = { name: String(body.name || 'Minha Loja').slice(0, 80), primary_color: /^#[0-9a-f]{6}$/i.test(body.primary_color) ? body.primary_color : '#c2410c',
      address: String(body.address || '').slice(0, 200), hours: String(body.hours || '').slice(0, 120), whats: String(body.whats || '').replace(/\D/g, '').slice(0, 15),
      logo_url: url(body.logo_url), banner_url: url(body.banner_url), profile_url: url(body.profile_url) };
    await sb.from('settings').update(s).eq('id', 1); return json(res, 200, { ok: true });
  }
  if (a === 'orders') return json(res, 200, (await sb.from('orders').select('*,order_items(name,qty,unit_price)').order('created_at', { ascending: false }).limit(300)).data);
  if (a === 'mp') {
    if (req.method === 'DELETE') { await sb.from('settings').update({ mp_token_enc: null, mp_user_id: null, mp_nick: null }).eq('id', 1); return json(res, 200, { ok: true }); }
    const t = String(body.accessToken || '').trim();
    const r = await fetch(MP + '/users/me', { headers: { Authorization: 'Bearer ' + t } });
    if (!t || !r.ok) return json(res, 400, { error: 'Access Token inválido. Confira no painel do Mercado Pago.' });
    const u = await r.json(); await sb.from('settings').update({ mp_token_enc: enc(t), mp_user_id: String(u.id), mp_nick: u.nickname || '' }).eq('id', 1);
    return json(res, 200, { ok: true, nickname: u.nickname });
  }
  json(res, 404, { error: 'not found' });
}
