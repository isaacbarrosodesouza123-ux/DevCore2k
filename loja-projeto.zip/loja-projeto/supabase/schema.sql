create extension if not exists pgcrypto;
create table if not exists settings(
 id int primary key default 1 check(id=1), name text default 'Minha Loja', primary_color text default '#c2410c',
 address text default '', hours text default '', whats text default '', logo_url text default '', banner_url text default '', profile_url text default '',
 mp_token_enc text, mp_user_id text, mp_nick text);
insert into settings(id) values(1) on conflict do nothing;
create table if not exists admin(id int primary key check(id=1), pw_hash text not null, pw_version bigint not null, created_at timestamptz default now());
create table if not exists products(
 id uuid primary key default gen_random_uuid(), name text not null, description text default '',
 price numeric(10,2) not null check(price>=0), promo_price numeric(10,2) check(promo_price>=0),
 stock int not null default 0 check(stock>=0), image_urls text[] default '{}', active boolean default true, created_at timestamptz default now());
create table if not exists orders(
 id uuid primary key default gen_random_uuid(), idem_key text unique, name text not null, email text not null, city text not null,
 total numeric(10,2) not null, status text not null default 'pendente' check(status in ('pendente','aprovado','recusado','estornado')),
 mp_preference_id text, mp_payment_id text unique, mp_status text, stock_applied boolean not null default false,
 created_at timestamptz default now(), paid_at timestamptz);
create table if not exists order_items(
 id bigserial primary key, order_id uuid references orders(id) on delete cascade, product_id uuid references products(id) on delete set null,
 name text not null, qty int not null check(qty>0), unit_price numeric(10,2) not null);
create table if not exists login_attempts(id bigserial primary key, ip text, kind text, at timestamptz default now());
-- RLS ligado e SEM policies: anon/authenticated nao leem nem gravam nada. So o backend (service role) acessa.
alter table settings enable row level security; alter table admin enable row level security; alter table products enable row level security;
alter table orders enable row level security; alter table order_items enable row level security; alter table login_attempts enable row level security;
create or replace function apply_stock(p_order uuid) returns boolean language plpgsql security definer set search_path=public as $$
begin
 update orders set stock_applied=true where id=p_order and stock_applied=false;
 if not found then return false; end if;
 update products p set stock=greatest(0,p.stock-i.qty) from order_items i where i.order_id=p_order and i.product_id=p.id;
 return true;
end $$;
revoke all on function apply_stock(uuid) from public, anon, authenticated;
insert into storage.buckets(id,name,public) values('products','products',true) on conflict do nothing;
-- Dados migrados da loja atual (o produto "Eu" parece ser de teste: apague no painel se quiser)
update settings set name='Eu', primary_color='#000000', address='Aqui em casa', hours='08:00 até as 20:09',
 logo_url='/img/ce0a613b5f56ec5b5599eda44f37b662.jpg', banner_url='/img/dbc6384b8b4144374bcce634ca2931d3.jpg' where id=1;
insert into products(name,description,price,promo_price,stock) select 'Eu','Isaac',10,5,100 where not exists(select 1 from products);
